from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

class CustomUserAdmin(UserAdmin):
    model = User

    list_display = ['username', 'email', 'is_active','is_superuser','is_admin']

    fieldsets = (
        (None, {'fields': ('username', 'email', 'password')}),
        ('Permissions', {'fields': ( 'is_active','is_superuser')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2', 'is_active','is_superuser','is_admin')}
        ),
    )

    search_fields = ('username', 'email')
    ordering = ('username',)

    filter_horizontal = ()
    list_filter = ()

admin.site.register(User, CustomUserAdmin)
