from django.urls import path
from .views import signup,signin,UserProfileView,UserProfileUpdate,SendOTP,VerifyOTP, add_role,update_role

urlpatterns = [
    path('signup/', signup, name='signup'),
    path('signin/', signin),
    path('viewprofile/', UserProfileView.as_view(), name='view_profile'),
    path('updateprofile/',UserProfileUpdate.as_view(), name='update_profile'),
    path('send-otp/', SendOTP.as_view(), name='send_otp'),
    path('verify-otp/', VerifyOTP.as_view(), name='verify_otp'),
    path('addrole/', add_role),
    path('updaterole/<int:pk>/', update_role),

]
